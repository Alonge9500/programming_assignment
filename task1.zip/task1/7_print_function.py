if __name__ == '__main__':
    n = int(input())
    output = ''
    for x in range(n):
        output = output + (str(x+1))
        
    print(output)
