if __name__ == '__main__':
    n = int(input())
    for i in range(n):
        print(i*i)
